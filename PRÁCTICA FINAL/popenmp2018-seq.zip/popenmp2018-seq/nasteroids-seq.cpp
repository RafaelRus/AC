//Includes necesarios
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string.h>
#include <vector>
#include <random>
//Std (no se ha realizado el std::chrono, porque se ha medido el tiempo con el comando time)
using namespace std;
//Constantes a utilizar a lo largo del problema (todas son double)
//Constante de gravitacion universal
const double const_gravit = 6.674e-5;
//Intervalo de tiempo
const double inter_tiempo = 0.1;
//Distancia minima
const double dmin = 2.0;
//Anchura del espacio
const double width = 200.0;
//Altura del espacio
const double height = 200.0;
//Media para el calculo de la distribucion normal de las masas
const double mass = 1000.0;
//Desviacion estandar para el calculo de la dist. normal de las masas
const double sdm = 50.0;
//Clase asteroide con visibilidad publica por defecto
struct asteroide {
	double pos_x = 0.0;
	double pos_y = 0.0;
	double masa = 0.0;
	double vel_x = 0.0;
	double vel_y = 0.0;
	//Tanto la fuerza_total_x como la fuerza_total_y sirven para acumular las fuerzas de cada asteroide (en cada iteracion)
	double fuerza_total_x = 0.0;
	double fuerza_total_y = 0.0;
};
//Clase planeta con visibilidad publica por defecto
struct planeta {
	double pos_x;
	double pos_y;
	double masa;
};
//Funciones declaradas (vienen definidas en la parte baja del codigo)
//Funcion para escribir el error de un paso incorrecto de parametros
void print_error_param();
//Calcula el modulo de la fuerza de atraccion entre dos asteroides (recibe los asteroides y la distancia entre ambos)
double calculo_fuerza_atraccion_asteroide(asteroide a, asteroide b, double dist_asteroide);
//Calcula el modulo de la fuerza de atraccion entre un asteroide y un planeta (recibe el asteroide, el planeta y la distancia entre ambos)
double calculo_fuerza_atraccion_planeta(asteroide a, planeta b, double dist_planeta);
//Calcula la distancia entre asteroides
double calculo_distancia_asteroide(asteroide a, asteroide b);
//Calcula la distancia entre un asteroide y un planeta
double calculo_distancia_planeta(asteroide a, planeta b);
//Calcula la pendiente entre asteroides
double calculo_pendiente_asteroide(asteroide a, asteroide b);
//Calcula la pendiente un asteroide y un planeta
double calculo_pendiente_planeta(asteroide a, planeta b);
//Calcula el angulo entre asteroides
double calculo_angulo_asteroide(double pendiente_aster);
//Calcula el angulo entre un asteroide y un planeta
double calculo_angulo_planeta(double pendiente_plane);
//Funcion principal
int main(int argc, char** argv){
	//Comprueba que se han introducido 5 parametros (numero de parametros correcto)
	if(argc != 5){
		//Si no se cumple, se procedera a terminar el programa con codigo de error -1 y un mensaje de error
		print_error_param();
		return -1;
	}
	else{
		//Comprueba que los parametros introducidos sean del tipo correcto (numeros enteros)
		//Primero se define el booleano valid_param (necesario para la siguiente comprobacion)
		int valid_param;
		for(int i = 1; i < argc; i++) {
			//Luego se declara la variable entera suma que se utilizara para comprobar que el ultimo parametro sea un numero entero positivo mayor que 0
			unsigned int suma = 0;
			for(unsigned int j = 0; j < strlen(argv[i]); j++) {
				//Se comprueba (signo por signo) que los parametros intoducidos son numeros enteros (entre 0 y 9)
				if(argv[i][j] >= '0' && argv[i][j] <= '9') {
					valid_param = 0;
					//Cuando se comprueba el ultimo parametro y despues de verificar que es un numero entero, se almacena cada signo en la variable entera suma (se almacena en codigo ascii)
					if(i == 4) {
						suma += argv[i][j];
					}
				}
				//Si no se cumple, se procedera a terminar el programa con codigo de error -1 y un mensaje de error (ademas se le asigna -1 a valid_param)
				else {
					valid_param = -1;
					print_error_param();
					return -1;
				}
			}
			//Despues de la comprobracion, verifica que el ultimo parametro sea un numero entero positivo
			if(i == 4) {
				//Dado que 0 es 48 en codigo ascii, se comprueba que la variable entera suma no sea igual que el producto de 48 por la longitud del ultimo parametro
				if(suma == 48 * strlen(argv[i])) {
					//Si no se cumple, se procedera a terminar el programa con codigo de error -1 y un mensaje de error (ademas se le asigna -1 a valid_param)
					valid_param = -1;
					print_error_param();
					return -1;
				}
			}
		}
		//Si los parametros introducidos son correctos, se mete en este if
		if(valid_param == 0) {
			//Define los parametros como enteros con el nombre correcto
			int num_asteroides = atoi(argv[1]);
			int num_iteraciones = atoi(argv[2]);
			int num_planetas = atoi(argv[3]);
			int semilla = atoi(argv[4]);
			//Calcula las distribuciones aleatorias (posicion en el espacio bidimensional y masa)
			default_random_engine re{semilla};
			uniform_real_distribution<double> xdist{0.0, nextafter(width, numeric_limits<double>::max())};
			uniform_real_distribution<double> ydist{0.0, nextafter(height, numeric_limits<double>::max())};
			normal_distribution<double> mdist{mass, sdm};
			//Define los vectores de los structs asteroide y planeta con el tamaño de los numeros de asteroides y planetas respectivamente
			vector<asteroide> param_asteroides(num_asteroides);
			vector<planeta> param_planetas(num_planetas);
			//Crea un fichero de salida 1
			ofstream fichero_salida1;
			fichero_salida1.open("init_conf.txt");
			//Envia la primera cadena al fichero de salida 1
			fichero_salida1 << num_asteroides << " " << num_iteraciones << " " << num_planetas << " " << semilla << endl;	
			//Envia el resto de cadena al fichero de salida 1
			//Primero envia los asteroides (se les asigna una posicion bidimensional en el espacio y una masa)
			for(int i = 0; i < num_asteroides; i++) {
				param_asteroides[i].pos_x = xdist(re);
				param_asteroides[i].pos_y = ydist(re);
				param_asteroides[i].masa = mdist(re);
				//Imprimir los 3 decimales cuando es coma flotante
				fichero_salida1 << fixed << setprecision(3) << param_asteroides[i].pos_x << " " << param_asteroides[i].pos_y << " " << param_asteroides[i].masa << endl;
			}
			//Luego envia los planetas (se les asigna una posicion bidimensional en el espacio y una masa)
			for(int j = 0; j < num_planetas; j++) {
				//El primer planeta se coloca en el borde izquierdo
				if(j == 0) {
					param_planetas[j].pos_x = 0.0;
					param_planetas[j].pos_y = ydist(re);
				}
				//El segundo planeta se coloca en el borde superior
				if(j == 1) {
					param_planetas[j].pos_x = xdist(re);
					param_planetas[j].pos_y = 0.0;
				}
				//El tercer planeta se coloca en el borde derecho
				if(j == 2) {
					param_planetas[j].pos_x = 200.0;
					param_planetas[j].pos_y = ydist(re);
				}
				//El cuarto planeta se coloca en el borde inferior
				if(j == 3) {
					param_planetas[j].pos_x = xdist(re);
					param_planetas[j].pos_y = 200.0;
				}
				//Si hay mas de cuatro planetas se colocan en el mismo orden (para ello se calcula el modulo de 4)
				if(j > 3) {
					if(j % 4 == 0) {
						param_planetas[j].pos_x = 0.0;
						param_planetas[j].pos_y = ydist(re);
					}
					if(j % 4 == 1) {
						param_planetas[j].pos_x = xdist(re);
						param_planetas[j].pos_y = 0.0;
					}
					if(j % 4 == 2) {
						param_planetas[j].pos_x = 200.0;
						param_planetas[j].pos_y = ydist(re);
					}
					if(j % 4 == 3) {
						param_planetas[j].pos_x = xdist(re);
						param_planetas[j].pos_y = 200.0;
					}
				}
				param_planetas[j].masa = 10 * mdist(re);
				//Imprimir los 3 decimales cuando es coma flotante
				fichero_salida1 << fixed << setprecision(3) << param_planetas[j].pos_x << " " << param_planetas[j].pos_y << " " << param_planetas[j].masa << endl;
			}
			//Cierra el fichero init_conf.txt
			fichero_salida1.close();
			//Bucle de iteraciones (cada vez que se hace el bucle de iteraciones se resta uno el num_iteraciones)
			while(num_iteraciones != 0) {
				//Lo primero que se va a hacer en cada iteracion es declarar la fuerza_total_x y fuerza_total_y de cada asteroide a 0 (ya que ambas actuan como sumatorios de fuerzas y en cada iteracion se deben reiniciar)
				for(int i = 0; i < num_asteroides; i++) {
					param_asteroides[i].fuerza_total_x = 0.0;
					param_asteroides[i].fuerza_total_y = 0.0;
				}
				//Luego se van a calcular todas las fuerzas de atraccion entre asteroides
				//Para ello se declara el siguiente bucle en que se calculara la fuerza de cada asteroide con el resto de asteroides
				for(int i = 0; i < num_asteroides; i++) {
					for(int j = i + 1; j < num_asteroides; j++) {
						//Se calcula la distancia entre ambos asteroides y se comprueba que sea mayor que la constante de minimo de distancia (si no lo es, no calcula la fuerza de atraccion entre esos dos asteroides)
						double nueva_distancia_asteroide = calculo_distancia_asteroide(param_asteroides[i], param_asteroides[j]);
						if(nueva_distancia_asteroide > dmin) {
							//Se declara una variable auxiliar que se utilizara para las fuerzas que actuan de forma negativa
							double variable_auxiliar_aster = 0.0;
							//Se calcula la pendiente entre ambos asteroides y se comprueba que no sea mayor que 1 y menor que -1 (en cuyo caso se realiza un static_cast <int> para corregir la pendiente)
							double nueva_pendiente_asteroide = calculo_pendiente_asteroide(param_asteroides[i], param_asteroides[j]);
							if(nueva_pendiente_asteroide > 1.0 || nueva_pendiente_asteroide < -1.0) {
								nueva_pendiente_asteroide = nueva_pendiente_asteroide - (static_cast <int> (nueva_pendiente_asteroide) / 1);
							}
							//Se calcula el angulo entre ambos asteroides (se utilizara mas tarde para calcular el vector de las fuerzas de atraccion)
							double nuevo_angulo_asteroide = calculo_angulo_asteroide(nueva_pendiente_asteroide);
							//Se calculo el modulo de las fuerzas de atraccion
							double fuerza_asteroide = calculo_fuerza_atraccion_asteroide(param_asteroides[i], param_asteroides[j], nueva_distancia_asteroide);
							//El valor maximo del modulo de la fuerza de atraccion entre dos asteroides sera de 200, por lo que cualquier calculo superior debera ser truncado a este valor (se multiplica 200 por el coseno o el seno del angulo dependiendo del eje x o y)
							if(fuerza_asteroide > 200.0) {
								//Fuerza x (con el coseno para calcular el vector de la fuerza de atraccion)
								param_asteroides[i].fuerza_total_x += (200.0 * cos(nuevo_angulo_asteroide));
								//Para el asteroide i, esta fuerza se aplica de forma positiva y para el asteroide j de forma negativa (se suma a la fuerza_total_x del asteroide j)
								variable_auxiliar_aster = -(200.0 * cos(nuevo_angulo_asteroide));
								param_asteroides[j].fuerza_total_x += variable_auxiliar_aster;
								//Fuerza y (con el seno para calcular el vector de la fuerza de atraccion)
								param_asteroides[i].fuerza_total_y += (200.0 * sin(nuevo_angulo_asteroide));
								//Para el asteroide i, esta fuerza se aplica de forma positiva y para el asteroide j de forma negativa (se suma a la fuerza_total_y del asteroide j)
								variable_auxiliar_aster = -(200.0 * sin(nuevo_angulo_asteroide));
								param_asteroides[j].fuerza_total_y += variable_auxiliar_aster;
							}
							else {
								//Fuerza x (con el coseno para calcular el vector de la fuerza de atraccion)
								param_asteroides[i].fuerza_total_x += (fuerza_asteroide * cos(nuevo_angulo_asteroide));
								//Para el asteroide i, esta fuerza se aplica de forma positiva y para el asteroide j de forma negativa (se suma a la fuerza_total_x del asteroide j)
								variable_auxiliar_aster = -(fuerza_asteroide * cos(nuevo_angulo_asteroide));
								param_asteroides[j].fuerza_total_x += variable_auxiliar_aster;
								//Fuerza y (con el seno para calcular el vector de la fuerza de atraccion)
								param_asteroides[i].fuerza_total_y += (fuerza_asteroide * sin(nuevo_angulo_asteroide));
								//Para el asteroide i, esta fuerza se aplica de forma positiva y para el asteroide j de forma negativa (se suma a la fuerza_total_y del asteroide j)
								variable_auxiliar_aster = -(fuerza_asteroide * sin(nuevo_angulo_asteroide));
								param_asteroides[j].fuerza_total_y += variable_auxiliar_aster;
							}
						}
					}
				}
				//Luego se van a calcular todas las fuerzas de atraccion entre asteroides y planetas
				//Para ello se declara el siguiente bucle en que se calculara la fuerza de cada asteroide con cada planeta
				for(int k = 0; k < num_planetas; k++) {
					for(int i = 0; i < num_asteroides; i++) {
						//Se calcula la distancia entre el asteroide y el planeta y se comprueba que sea mayor que la constante de minimo de distancia (si no lo es, no calcula la fuerza de atraccion entre el asteroide y el planeta)
						double nueva_distancia_planeta = calculo_distancia_planeta(param_asteroides[i], param_planetas[k]);	
						if(nueva_distancia_planeta > dmin) {
							//Se calcula la pendiente entre el asteroide y el planeta y se comprueba que no sea mayor que 1 y menor que -1 (en cuyo caso se realiza un static_cast <int> para corregir la pendiente)
							double nueva_pendiente_planeta = calculo_pendiente_planeta(param_asteroides[i], param_planetas[k]);
							if(nueva_pendiente_planeta > 1.0 || nueva_pendiente_planeta < -1.0) {
								nueva_pendiente_planeta = nueva_pendiente_planeta - (static_cast <int> (nueva_pendiente_planeta) / 1);
							}
							//Se calcula el angulo entre el asteroide y el planeta (se utilizara mas tarde para calcular el vector de las fuerzas de atraccion)
							double nuevo_angulo_planeta = calculo_angulo_planeta(nueva_pendiente_planeta);
							//Se calculo el modulo de las fuerzas de atraccion
							double fuerza_planeta = calculo_fuerza_atraccion_planeta(param_asteroides[i], param_planetas[k], nueva_distancia_planeta);
							//El valor maximo del modulo de la fuerza de atraccion entre dos asteroides sera de 200, por lo que cualquier calculo superior debera ser truncado a este valor (se multiplica 200 por el coseno o el seno del angulo dependiendo del eje x o y)
							if(fuerza_planeta > 200.0) {
								//Fuerza x (con el coseno para calcular el vector de la fuerza de atraccion)
								param_asteroides[i].fuerza_total_x += (200.0 * cos(nuevo_angulo_planeta));
								//Fuerza y (con el seno para calcular el vector de la fuerza de atraccion)
								param_asteroides[i].fuerza_total_y += (200.0 * sin(nuevo_angulo_planeta));
							}
							else {
								//Fuerza x (con el coseno para calcular el vector de la fuerza de atraccion)
								param_asteroides[i].fuerza_total_x += (fuerza_planeta * cos(nuevo_angulo_planeta));
								//Fuerza y (con el seno para calcular el vector de la fuerza de atraccion)
								param_asteroides[i].fuerza_total_y += (fuerza_planeta * sin(nuevo_angulo_planeta));
							}
						}
					}
				}
				//Movimiento de todos los asteroides: partiendo de la fuerza total, calcular la nueva posicion
				for(int i = 0; i < num_asteroides; i++) {
					//Se crean las aceleraciones de cada eje, y se dividen los sumatorios de las fuerzas de atraccion entre la masa de cada asteroide
					double acel_x = param_asteroides[i].fuerza_total_x / param_asteroides[i].masa;
					double acel_y = param_asteroides[i].fuerza_total_y / param_asteroides[i].masa;
					//Se calculan las nuevas velocidades y posiciones para cada asteroide
					param_asteroides[i].vel_x += acel_x * inter_tiempo;
					param_asteroides[i].vel_y += acel_y * inter_tiempo;
					param_asteroides[i].pos_x += param_asteroides[i].vel_x * inter_tiempo;
					param_asteroides[i].pos_y += param_asteroides[i].vel_y * inter_tiempo;
				}
				//Luego se evalua el rebote con los bordes del espacio (en cada iteracion)
				//Se debera comprobar que llega a un borde del espacio, y luego posicionarse a 2 puntos del espacio
				for(int i = 0; i < num_asteroides; i++) {
					//Con el borde izquierdo
					if(param_asteroides[i].pos_x <= 0.0) {
						param_asteroides[i].pos_x = 2.0;
						param_asteroides[i].vel_x = -(param_asteroides[i].vel_x);
					}
					//Con el borde superior
					if(param_asteroides[i].pos_y <= 0.0) {
						param_asteroides[i].pos_y = 2.0;
						param_asteroides[i].vel_y = -(param_asteroides[i].vel_y);
					}
					//Con el borde derecho
					if(param_asteroides[i].pos_x >= width) {
						param_asteroides[i].pos_x = width - 2.0;
						param_asteroides[i].vel_x = -(param_asteroides[i].vel_x);
					}
					//Con el borde inferior
					if(param_asteroides[i].pos_y >= height) {
						param_asteroides[i].pos_y = height - 2.0;
						param_asteroides[i].vel_y = -(param_asteroides[i].vel_y);
					}
				}
				//Por ultimo, se evalua el rebote entre asteroides
				//Primero se crea un vector de booleanos que se encargara de asignar el valor 1 a todos los asteroides que chocan y el valor 0 a los que no chocan
				vector<int> comprobacion_rebotes(num_asteroides);
				//Se inicializan todos a 0
				for(unsigned int l = 0; l < comprobacion_rebotes.size(); l++) {
					comprobacion_rebotes[l] = 0;
				}
				//Se comprueba el rebote entre cada asteroide con el resto en orden
				for(int i = 0; i < num_asteroides - 1; i++) {
					//Se crea el vector de punteros choque_asteroides que se encargara de almacenar las posiciones de los asteroides que chocan
					vector<asteroide*> choque_asteroides;
					//Se crea la variable entera cont que se encargara de garantizar que en el vector de punteros se almacenan en orden correcto las posiciones de los asteroides que chocan
					int cont = 0;
					for(int j = i + 1; j < num_asteroides; j++) {
						//Calcula la distancia entre cada par de asteroides
						double distancia_aste = calculo_distancia_asteroide(param_asteroides[i], param_asteroides[j]);
						//Si la distancia es menor o igual que 2, cont es 0 (el vector choque_asteroides esta vacio todavia) y el asteroide i tiene valor 0 en el vector comprobacion_rebotes (todavia no ha chocado con ningun otro asteroide y por tanto puede intercambiarse las velocidades), se hace lo siguiente
						if(distancia_aste <= 2.0 && cont == 0 && comprobacion_rebotes[i] == 0) {
							//Se añade la posicion del asteroide i al vector de punteros
							choque_asteroides.push_back(&param_asteroides[i]);
							//Cont cambia a 1
							cont = 1;
							//Se cambia el valor a 1 del asteroide i en el vector de booleanos comprobacion_rebotes
							comprobacion_rebotes[i] = 1;
						}
						//Una vez añadida la posicion del asteroide i al vector de punteros, se añaden el resto de asteroides j con los que choca (debido a que cont ahora es 1)
						if(distancia_aste <= 2.0 && cont == 1) {
							choque_asteroides.push_back(&param_asteroides[j]);
							comprobacion_rebotes[j] = 1;
						}
					}
					//Si el vector de punteros no esta vacio, se intercambiaran todas las velocidades
					if(choque_asteroides.size() > 0) {
						//Se guardan las del primer asteroide para luego darselas al ultimo asteroide
						double aux_vel_x = choque_asteroides[0] -> vel_x;
						double aux_vel_y = choque_asteroides[0] -> vel_y;
						for(unsigned int k = 0; k < choque_asteroides.size(); k++) {
							//Si no es el ultimo, se cambia la velocidad de cada asteroide por la del siguiente en el vector de punteros
							if(k != choque_asteroides.size() - 1) {
								choque_asteroides[k] -> vel_x = choque_asteroides[k + 1] -> vel_x;
								choque_asteroides[k] -> vel_y = choque_asteroides[k + 1] -> vel_y;
							}
							//Si es el ultimo, se le da la del primero
							else {
								choque_asteroides.back() -> vel_x = aux_vel_x;
								choque_asteroides.back() -> vel_x = aux_vel_y;
							}
						}
					}					
				}
				//Se decrementa el num_iteraciones en cada iteracion
				num_iteraciones--;
			}
			//Crea un fichero de salida 3
			ofstream fichero_salida3;
			fichero_salida3.open("out.txt");
			//Una vez finalizados todas las iteraciones de la simulacion se debe realizar un almacenamiento de los datos finales de la misma con estos datos
			for(int i = 0; i < num_asteroides; i++) {
				fichero_salida3 << fixed << setprecision(3) << param_asteroides[i].pos_x << " " << param_asteroides[i].pos_y << " " << param_asteroides[i].vel_x << " " << param_asteroides[i].vel_y << " " << param_asteroides[i].masa << endl;
			}
			fichero_salida3.close();
			//Se termina el programa
			return 0;
		}
	}
}
void print_error_param(){
	cerr << "nasteroids-seq: Wrong arguments." << endl;	
	cerr << "Correct use: " << endl;
	cerr << "nasteroids-seq num_asteroides num_iteraciones num_planetas semilla" << endl;	
}
double calculo_fuerza_atraccion_asteroide(asteroide a, asteroide b, double dist_asteroide) {
	double fuerza_atraccion_asteroide_funcion = ((const_gravit * a.masa * b.masa) / pow(dist_asteroide, 2));
	return fuerza_atraccion_asteroide_funcion;
}
double calculo_fuerza_atraccion_planeta(asteroide a, planeta b, double dist_planeta) {
	double fuerza_atraccion_planeta_funcion = ((const_gravit * a.masa * b.masa) / pow(dist_planeta, 2));
	return fuerza_atraccion_planeta_funcion;
}
double calculo_distancia_asteroide(asteroide a, asteroide b) {
	double distancia_asteroide_funcion = sqrt(pow((a.pos_x - b.pos_x), 2) + pow((a.pos_y - b.pos_y), 2));
	return distancia_asteroide_funcion;
}
double calculo_distancia_planeta(asteroide a, planeta b) {
	double distancia_planeta_funcion = sqrt(pow((a.pos_x - b.pos_x), 2) + pow((a.pos_y - b.pos_y), 2));
	return distancia_planeta_funcion;
}
double calculo_pendiente_asteroide(asteroide a, asteroide b) {
	double pendiente_asteroide_funcion = (a.pos_y - b.pos_y) / (a.pos_x - b.pos_x);
	return pendiente_asteroide_funcion;
}
double calculo_pendiente_planeta(asteroide a, planeta b) {
	double pendiente_planeta_funcion = (a.pos_y - b.pos_y) / (a.pos_x - b.pos_x);
	return pendiente_planeta_funcion;
}
double calculo_angulo_asteroide(double pendiente_aster) {
	double angulo_asteroide_funcion = atan(pendiente_aster);
	return angulo_asteroide_funcion;
}
double calculo_angulo_planeta(double pendiente_plane) {
	double angulo_planeta_funcion = atan(pendiente_plane);
	return angulo_planeta_funcion;
}